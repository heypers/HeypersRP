════════════════════════════════
       Important Info
════════════════════════════════
Look at the "INFO" folder for get 
information about weapons, uniforms, 
commands and more.

════════════════════════════════
      Thanks for download
════════════════════════════════